package ubu.pam.mydog;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView สายพันธุ์สุนัข = (TextView)findViewById(R.id.tv2);
        สายพันธุ์สุนัข.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(MainActivity.this ,page2.class);
                startActivity(a);
            }
        });

        TextView การดูแลสุนัข = (TextView)findViewById(R.id.tv3);
        การดูแลสุนัข.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(MainActivity.this, page3.class);
                startActivity(j);
            }
        });

        TextView แนะนำโรงแรมสำหรับน้องหมา = (TextView)findViewById(R.id.tv4);
        แนะนำโรงแรมสำหรับน้องหมา.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent k = new Intent(MainActivity.this, page4.class);
                startActivity(k);
            }
        });

        TextView แนะนำสถานที่ท่องเที่ยว = (TextView)findViewById(R.id.tv5);
        แนะนำสถานที่ท่องเที่ยว.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent l = new Intent(MainActivity.this, page5.class);
                startActivity(l);
            }
        });

        TextView แนะนำเพจน้องหมาสุดน่ารัก = (TextView)findViewById(R.id.tv6);
        แนะนำเพจน้องหมาสุดน่ารัก.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent m = new Intent(MainActivity.this, page6.class);
                startActivity(m);
            }
        });
    }
}
