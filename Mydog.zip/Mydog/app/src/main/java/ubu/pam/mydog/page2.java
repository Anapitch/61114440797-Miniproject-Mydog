package ubu.pam.mydog;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class page2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);

        TextView ลาบราดอร์ริทรีฟเวอร์ = (TextView)findViewById(R.id.textView1);
        ลาบราดอร์ริทรีฟเวอร์.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent b = new Intent(page2.this ,page2_1.class);
                startActivity(b);
            }
        });

        TextView โกลเดนริทรีฟเวอร์ = (TextView)findViewById(R.id.textView2);
        โกลเดนริทรีฟเวอร์.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent c = new Intent(page2.this ,page2_2.class);
                startActivity(c);
            }
        });

        TextView ไทยหลังอาน = (TextView)findViewById(R.id.textView3);
        ไทยหลังอาน.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent d = new Intent(page2.this ,page2_3.class);
                startActivity(d);
            }
        });

        TextView ไซบีเรียนฮัสกี = (TextView)findViewById(R.id.textView4);
        ไซบีเรียนฮัสกี.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent e = new Intent(page2.this ,page2_4.class);
                startActivity(e);
            }
        });

        TextView ปอมเมอราเนียน = (TextView)findViewById(R.id.textView5);
        ปอมเมอราเนียน.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent f = new Intent(page2.this ,page2_5.class);
                startActivity(f);
            }
        });

        TextView ชิบะอินุ = (TextView)findViewById(R.id.textView6);
        ชิบะอินุ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent g = new Intent(page2.this ,page2_6.class);
                startActivity(g);
            }
        });

        TextView ซามอย = (TextView)findViewById(R.id.textView7);
        ซามอย.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent h = new Intent(page2.this ,page2_7.class);
                startActivity(h);
            }
        });

        TextView ปั๊ก = (TextView)findViewById(R.id.textView8);
        ปั๊ก.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(page2.this, page2_8.class);
                startActivity(i);
            }
        });
    }
}
